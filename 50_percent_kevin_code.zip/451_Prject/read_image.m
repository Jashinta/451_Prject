function read_image(file)
data = imread(file);


save ('data.mat', 'data');