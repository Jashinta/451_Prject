%% Fun With Filters (with Step Count, no FFT)
function extend (filename)

DURATION = 51616;

if (nargin == 0)
	filename = 'kevwalk.txt';
end

close all;

%% parse and resample sensor data
%androidAPP(filename);
load data.mat;
n = 1:accData(1, end); 
extended = zeros(3,length(n));
count = 0;
for i = 1:length(accData)
    while (accData(1,i) > count)
        count = count + 1;
        extended(1,count) =  accData(2,i);
        extended(2,count) =  accData(3,i);
        extended(3,count) =  accData(4,i);  
    end
end

%% Compute squares, magnitude, un bias 
x2  = extended(1,1:DURATION).^2;
y2  = extended(2,1:DURATION).^2;
z2  = extended(3,1:DURATION).^2;
mag = sqrt(x2+y2+z2);

%% Build filters

% Equiripple Lowpass filter designed using the FIRPM function.
% All frequency values are in Hz.
% Fs = 1000;  % Sampling Frequency

% Fpass = 1;               % Passband Frequency
% Fstop = 140;             % Stopband Frequency
% Dpass = 0.057501127785;  % Passband Ripple
% Dstop = 0.0001;          % Stopband Attenuation
% dens  = 20;              % Density Factor
d140 = drop140();


%% Populate struct array
pStruct(1).name = 'original';
pStruct(1).x 	= extended(1,1:DURATION);
pStruct(1).y 	= extended(2,1:DURATION);
pStruct(1).z 	= extended(3,1:DURATION);
pStruct(1).mag	= mag;
me = mag;

pStruct(2).name = 'STDF 140HZ filter, N = 500';
pStruct(2).x	= stdf  ( d140, pStruct( 1 ).x,   500);
pStruct(2).y	= stdf  ( d140, pStruct( 1 ).y,   500);
pStruct(2).z	= stdf  ( d140, pStruct( 1 ).z,   500);
pStruct(2).mag	= stdf  ( d140, pStruct( 1 ).mag, 500);

steps = zeros(1,DURATION);
longAverage = zeros(1,DURATION);
shortAverage = zeros(1,DURATION);
stepCount = 0;
for i = 2001:DURATION
    longAverage(i) = mean(pStruct(1).mag(i-2000:i));
    shortAverage(i) = mean(pStruct(1).mag(i-100:i));
    if( shortAverage(i) > longAverage(i) )
        steps(i) = 1;
        if(steps(i-1) ~= 1 )
            stepCount = stepCount + 1;
        end
    else
        steps(i) = 0;
    end
end

%% Plot
figure;
subplot(2,1,2);
plot(me);
axis([0 DURATION 0 25]);
subplot(2,1,1);
plot (steps);
axis([0 DURATION 0 2]);
stepCount

plotStruct(pStruct,2);

end
