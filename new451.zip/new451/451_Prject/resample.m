close all;
load data.mat;

time   = accData(1, :);
xvalue = accData(2, :);
yvalue = accData(3, :);
zvalue = accData(4, :);

r_time   = time(1):10000:time(end);
r_xvalue = interp1(time, xvalue, r_time);
r_yvalue = interp1(time, yvalue, r_time);
r_zvalue = interp1(time, zvalue, r_time);

mag = sqrt( r_xvalue.^2 + r_yvalue.^2 + r_zvalue.^2 );
normalized_mag = mag - mean(mag);

for t = 11:length(normalized_mag)
    short_freq = fftshift(fft(normalized_mag(t-10:t)));
%     for i = 1:15
%         short_freq(i) = 0;
%     end
%     for i = 35:50
%         short_freq(i) = 0;
%     end
    % insert filter
    short_power(t) = (sum(abs(short_freq) .^ 2))/10;
end

for t = 201:length(normalized_mag)
    long_freq  = fftshift(fft(normalized_mag(t-200:t)));
%     for i = 1:98
%         long_freq(i) = 0;
%     end
%     for i = 102:200
%         long_freq(i) = 0;
%     end
    long_power(t) = (sum(abs(long_freq) .^ 2))/200;
end

cutoff = abs(median(long_power));

steps = zeros(1,length(normalized_mag));
stepCount = 0;
for t = 2:length(normalized_mag)
    if( short_power(t) > (long_power(t)) )
        steps(t) = 1;
        if(steps(t-1) ~= 1 )
            stepCount = stepCount + 1;
        end
    else
        steps(t) = 0;
    end
end

figure;
hold on;
plot(1:length(normalized_mag), long_power,'r');
plot(1:length(normalized_mag), short_power,'g');
plot(1:length(normalized_mag),(normalized_mag.*mean(long_power))./max(normalized_mag));
hold off;

figure;
plot(1:length(normalized_mag), short_power - long_power);
stepCount
